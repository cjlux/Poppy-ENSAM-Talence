# -*- coding: utf-8 -*-

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
# Appel des modules nécessaires (bibliothèques) #
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
from math import atan2, sin, cos, degrees, radians, sqrt

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
#    Définition de la classe 'PtGeom'           #
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
class PtGeom :
    u'Classe de points géometriques (sans directive graphique)'

    # Le Constructeur polymorphe peut prende un argument
    # de type PtGeom ou de type liste :
    def __init__(self, xyOrPt = [0, 0]):
        if isinstance(xyOrPt, PtGeom) : ### copie d'un objet PtGeom existant
            pt = xyOrPt                 # le nom pt est plus lisible..
            self.__x = pt.getX()        # att. privé x : abscisse
            self.__y = pt.getY()        # att. privé y : ordonnée
        else :                          ### liste donnant abscisse et ordonnée
            xy = xyOrPt                 # le nom xy est plus lisible...
            self.__x = float(xy[0])     # att. privé x : abscisse
            self.__y = float(xy[1])     # att. privé y : ordonnée
        # MAJ des doord. polaires :   
        self.__updateRhoTheta()      

    # Méthodes d'accès en lecture :
    def getX(self): return self.__x
    def getY(self): return self.__y
    def getXY(self): return self.__x, self.__y
    
    def getRho(self): return self.__r
    def getTheta(self): return degrees(self.__a)
    def getRhoTheta(self): return self.__r, degrees(self.__a)
    
    # Méthodes d'accès en écriture :
    def setX(self, newx):
        self.__x = float(newx)
        self.__updateRhoTheta()
            
    def setY(self, newy):
        self.__y = float(newy)
        self.__updateRhoTheta()
            
    def setRho(self, newr):
        self.__r = float(newr)
        self.__updateXY()
            
    def setTheta(self, newa):
        self.__a = radians(float(newa))
        self.__updateXY()
        
    def move(self, dx, dy):
        self.__x += dx
        self.__y += dy
        self.__updateRhoTheta()        

    # Méthodes privées :
    def __updateRhoTheta(self):
        self.__r = sqrt(self.__x**2 + self.__y**2)
        self.__a = atan2(self.__y, self.__x)

    def __updateXY(self):         
        self.__x = self.__r * cos(self.__a)
        self.__y = self.__r * sin(self.__a)
         
    # Affichage des attributs
    def info(self):
        return u"Abscisse %.3f ; ordonnee %.3f ; rayon %.3f ; azimuth %.1f°"\
              % (self.getX(), self.getY(), self.getRho(), self.getTheta())
    
    def prt(self):
        print u'===========\n', self, '\n ', self.info(), '\n'


if __name__ == "__main__":
    
    # Partie du code Python qui n'est exécuté que si ce fichier
    # est interprété directement (sans passer par un 'import PtGeom')
    # Ceci est très utile pour écrire des lignes qui testent la classe...
    
    # Test de toutes les façons d'appeler le constructeur :
    pt1 = PtGeom()           # constructeur appelé sans argument    
    pt2 = PtGeom([1.,-2.5])  # constructeur appelé avec une liste de deux flottants
    pt3 = PtGeom(['-1','1']) # constructeur appelé avec une liste de deux str

    pt4 = PtGeom(pt1)        # constructeur par duplication
    pt4.move(-1.5,3)         # test de la méthode move()

    # Test des méthodes d'accès :
    pt1.prt()
    pt2.prt()
    pt3.prt()
    pt4.prt()

    # Test méthode setTheta:
    tht = 55
    pt3.setTheta(tht)
    if pt3.getX() == pt3.getRho()*cos(radians(tht)) and\
       pt3.getY() == pt3.getRho()*sin(radians(tht)) :
        print u"Test setTheta OK"
    else :
        print u"Problème dans setTheta"
    
