# -*- coding: utf-8 -*-

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
#  Chargement des modules nécessaires (bibliothèques)        #
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
from math import atan2, sin, cos, degrees, radians, sqrt
from matplotlib.pyplot import figure, plot, text, show

from Utils import setAutoRange, ref

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
#  Chargement de la définition de la classe de base PtGeom   #
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
from PtGeom_plus import PtGeom
 
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
#  Définition de la classe 'PtGraph' qui dérive de 'PtGeom'  #
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
class PtGraph(PtGeom) :
    'Classe de points avec directives graphiques'
    
    __lptg = []  # Variable statique : liste des points créés
    
    def __init__(self, labelOrPtGra, pt = [0, 0], marker = 'o'):
        if isinstance(labelOrPtGra, PtGraph) : ### copie d'un objet PtGraph
            ptg = labelOrPtGra                     # plus lisible...
            # Appel du constructeur de la classe mère PtGeom,
            # avec l'argument l'objet ptg qui "est un" PtGeom :
            PtGeom.__init__(self, ptg)  
                                   
            self.__label = ptg.getLabel()          # étiquette du point
            self.__mrk   = ptg.getMarker()         # type de point
            self.__size  = ptg.getSize()           # taille du point
            self.__color = ptg.getColor()          # couleur du point
            self.__fillColor = ptg.getFillColor()  # couleur du contour du point
        else :                              ### labelOrPtGraph est un label
            label = labelOrPtGra              # plus lisible...
            # Appel du constructeur de la classe mère PtGeom
            # pt est soit un couple, soit un objet de type 'PtGeom'
            PtGeom.__init__(self, pt)       
            self.__label = label                # étiquette du point
            self.__mrk   = marker               # type de point
            self.__size  = 7.0                  # taille du point
            self.__color = 'black'              # couleur du point
            self.__fillColor = 'gray'           # couleur du contour du point
        
        PtGraph.__lptg.append(self) # Mise à jour de la listes des points créés

# Remarque : pour les types de points, voir
# http://matplotlib.sourceforge.net/api/artist_api.html#matplotlib.lines.Line2D.set_marker
            
    # Méthodes d'accès en lecture :
    def getColor(self): return self.__color
    def getFillColor(self): return self.__fillColor
    def getSize(self): return self.__size
    def getLabel(self): return self.__label
    def getMarker(self): return self.__mrk
    
    # Méthodes d'accès en écriture :
    def setColor(self, clr): self.__color = clr
    def setFillColor(self, fclr): self.__fillColor = fclr
    def setSize(self, sz): self.__size = sz
    def setMarker(self, mk): self.__mrk = mk
    def setColors(self, color, fillColor=None):
        self.setColor(color)
        if fillColor == None :
            self.setFillColor(color)
        else:
            self.setFillColor(fillColor)
               
    # Tracé du point :
    def plot(self, showLabel=False, noFig=1) :
        figure(noFig)
        plot([self.getX()],[self.getY()],
             marker = self.getMarker(),
             markeredgecolor = self.getColor() ,
             markerfacecolor = self.getFillColor(),
             markersize = self.getSize(),
             markeredgewidth = 1.2)
        if showLabel :
            text(self.getX(),self.getY(),'  '+self.getLabel(), color = self.getColor())
    
    # Affichage des attributs :
    def info(self):
        return ("Point %s :\t" % self.getLabel())+PtGeom.info(self)+\
               ("\n\t\tgrosseur %.1f ; couleurs '%s/%s'" % \
                (self.getSize(), self.getColor(), self.getFillColor()))

    # Méthodes statiques :
    @staticmethod
    def nb():
        return len(PtGraph.__lptg)
    
    @staticmethod
    def plotAll(showetiq = False):
        for ptg in PtGraph.__lptg :
            ptg.plot(showetiq)
        setAutoRange()
        show()
    
    @staticmethod
    def select(labels):
        if isinstance(labels,list) :
            liste = []
            for ptg in PtGraph.__lptg :
                if ptg.getLabel() in labels :
                    liste.append(ptg)
            print "====\n", len(liste), u"point(s) trouvé(s) avec les étiquettes", labels
        else :
            liste = []
            for ptg in PtGraph.__lptg :
                if ptg.getLabel() == labels :
                    liste.append(ptg)
            print "====\n", len(liste), u"point(s) trouvé(s) avec l'étiquette", labels            
        return liste

if __name__ == "__main__":
    
    # Partie du code Python qui n'est exécuté que si ce fichier
    # est interprété directement (sans passer par un 'import PtGraph')
    # Ceci est très utile pour écrire des lignes qui testent la classe...
    
    # Test de toutes les façons d'appeler le constructeur :
    # Constructeur appelé avec un seul argument :
    pt1 = PtGraph('A')             
    pt1.prt()
    
    # Constructeur appelé avec deux arguments :
    pt2 = PtGraph('B' ,[1.,-2.5])  
    pt2.setMarker('s')             # modification de la forme
    pt2.setColors('magenta')       # modification des couleurs
    pt2.prt()

    # Constructeur appelé avec un point géométrique
    pg1 = PtGeom(['-1','1'])        # création d'une instance de 'PtGeom'
    pt3 = PtGraph('C', pg1)         
    pt3.setColors('red','pink')
    pt3.setMarker('*')
    pt3.prt()

    # Construction par copie :
    pt4 = PtGraph(pt1)        
    pt4.move(-2.5,-2)
    pt4.prt()

    
    print u"Nombre de points créés :", PtGraph.nb()

    PtGraph.plotAll(True)

    for ptg in PtGraph.select('B'):
        ptg.prt()

    for ptg in PtGraph.select(['A','B']):
        ptg.plot(True)
    setAutoRange()
    show()
    
