# -*- coding: utf-8 -*-

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
#  Chargement des modules nécessaires (bibliothèques)        #
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
from math import atan2, sin, cos, degrees, radians, sqrt
from matplotlib.pyplot import figure, plot, text, show

from Utils import setAutoRange, ref

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
#  Chargement de la définition de la classe de base PtGeom   #
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
from PtGeom import PtGeom
 
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
#  Définition de la classe 'PtGraph' qui dérive de 'PtGeom'  #
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
class PtGraph(PtGeom) :
    u'Classe de points avec directives graphiques'
    
    def __init__(self, label, pt = [0, 0],  marker = 'o'):
        PtGeom.__init__(self, pt)    # Appel du constructeur de la classe mère PtGeom !
        
        self.__label = label         # étiquette du point
        self.__mrk   = marker        # type de point
        self.__size  = 7.0           # taille du point
        self.__color = 'black'       # couleur du point
        self.__fillColor = 'gray'    # couleur du contour du point
        
# Remarque : pour les types de points, voir
# http://matplotlib.org/api/markers_api.html#module-matplotlib.markers
            
    # Méthodes d'accès en lecture :
    def getColor(self): return self.__color
    def getFillColor(self): return self.__fillColor
    def getSize(self): return self.__size
    def getLabel(self): return self.__label
    def getMarker(self): return self.__mrk
    
    # Méthodes d'accès en écriture :
    def setColor(self, clr): self.__color = clr
    def setFillColor(self, fclr): self.__fillColor = fclr
    def setSize(self, sz): self.__size = sz
    def setMarker(self, mk): self.__mrk = mk
    def setColors(self, color, fillColor=None):
        self.setColor(color)
        if fillColor == None :
            self.setFillColor(color)
        else:
            self.setFillColor(fillColor)        
               
    # Tracé du point :
    def plot(self, showLabel=False, noFig=1) :
        figure(noFig)
        plot([self.getX()],[self.getY()],
             marker = self.getMarker(),
             markeredgecolor = self.getColor() ,
             markerfacecolor = self.getFillColor(),
             markersize = self.getSize(),
             markeredgewidth = 1.2)
        if showLabel :
            text(self.getX(),self.getY(),'  '+self.getLabel(), color = self.getColor())
    
    # Affichage des attributs :
    def info(self):
        return ("Point %s :\t" % self.getLabel())+PtGeom.info(self)+\
               ("\n\t\ttaille %.1f ; couleurs '%s/%s'\n" % \
                (self.getSize(), self.getColor(), self.getFillColor()))

if __name__ == "__main__":
    
    # Partie du code Python qui n'est exécuté que si ce fichier
    # est interprété directement (sans passer par un 'import PtGraph.py')
    # Ceci est très utile pour écrire des lignes qui testent la classe...
    
    # Test de toutes les façons d'apeller le constructeur :

    # Constructeur appelé sans 1 argument :
    pt1 = PtGraph('A')             
    print pt1.info()

    # Constructeur appelé avec 2 arguments :
    pt2 = PtGraph('B', [1.,-1.5])  
    pt2.setColors('green')
    print pt2.info()

    pt3 = PtGraph('C', ['-1','1']) 
    pt3.setColors('red','pink')
    print pt3.info()

    # Constructeur appelé avec 3 arguments :
    pt4 = PtGraph('D', [-1,0.5], '^')
    pt4.setColors('blue','magenta')
    print pt4.info()

    
    figure()
    pt1.plot(True)
    pt2.plot(True)
    pt3.plot(True)
    pt4.plot(True)
    
    setAutoRange()
    show()
